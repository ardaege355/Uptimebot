## Discord Uptime Bot Altyapısı!

## 📑 Bot Özellikleri

- [x] Butonlu
- [x] Formlu
- [x] Ayarlamalı

## 📷 Görseller
![image](https://media.discordapp.net/attachments/1016663875342569562/1051204881521836041/image.png?width=503&height=202)

![image](https://media.discordapp.net/attachments/1016663875342569562/1051204830884012052/image.png?width=375&height=168)
